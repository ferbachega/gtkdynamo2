#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  amber.py
#  
#  Copyright 2013 Fernando Bachega <fernando@bachega>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  

#!/usr/bin/env python

text1 = """
#	
#
#	
#	
#
#	
#
#                           ---- GTKDynamo ----
#		                    
#		
#       Copyright 2012 Jose Fernando R Bachega  <ferbachega@gmail.com>
#
#               visit: https://sites.google.com/site/gtkdynamo/
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       GTKDynamo team:
#       - Jose Fernando R Bachega  < Univesity of Sao Paulo - SP, Brazil                              >
#       - Troy Wymore              < Pittsburgh Super Computer Center, Pittsburgh PA - USA            >
#       - Martin Field             < Institut de Biologie Structurale, Grenoble, France               >		
#       - Luis Fernando S M Timmers< Pontifical Catholic University of Rio Grande do Sul - RS, Brazil >
#
#       Special thanks to:
#       - Lucas Assirati           < Univesity of Sao Paulo - SP, Brazil                              >
#       - Leonardo R Bachega       < University of Purdue - West Lafayette, IN - USA                  >
#       - Richard Garratt          < Univesity of Sao Paulo - SP, Brazil                              >
#
#
#		
"""  


texto_d1   = "\n\n                       -- simple-distance --\n\nFor simple-distance, select two atoms in pymol using the editing mode\nfollowing the diagram:\n\n   R                    R\n    \                  /\n     A1--A2  . . . . A3\n    /                  \ \n   R                    R\n         ^            ^\n         |            |\n        pk1  . . . . pk2\n                d1\n"
texto_d2d1 = "\n                       -- multiple-distance --\n\nFor multiple-distance, select three atoms in pymol using the editing mode\nfollowing the diagram:\n\n   R                    R\n    \                  /\n     A1--A2  . . . . A3\n    /                  \ \n   R                    R\n     ^   ^            ^\n     |   |            |\n    pk1-pk2  . . . . pk3\n       d1       d2\n"



dialog_text = { 
				'error_topologies/Parameters' : "Error: the topology, parameters or coordinates do not match the system type: ",
				'error_coordiantes'           : "Error: the coordinates do not match the loaded system.",
				'error_trajectory'            : "Error: the trajectory does not match the loaded system.",
				'delete'                      : "Delete memory system.",
				'prune'                       : "Warning: this is an irreversible process. Do you want to continue?",
				'qc_region'                   : "Warning: no quantum region has been defined. Would you like to put all atoms in the quantum region?",
				'delete2'                     : "Warning: there is a system loaded in memory. Are you sure that you want to delete it?"
				}


#System
import datetime
import time
import pygtk
pygtk.require('2.0')
import gtk


import thread
import threading
import gobject
import sys
import glob, math, os




if not sys.platform.startswith('win'):
    HOME         = os.environ.get('HOME')
else:            
    HOME         = os.environ.get('PYMOL_PATH')


GTKDYNAMO_ROOT   = os.environ.get('GTKDYNAMO_ROOT')
GTKDYNAMO_GUI    = os.path.join(GTKDYNAMO_ROOT,"gui")


try:
	#gtk.rc_parse('gtkrc')
	gtk.rc_parse( os.path.join(GTKDYNAMO_ROOT,'.gtkrc'))

except:
	print '\n\n\ file not found \n\n'
	pass


builder = gtk.Builder()
builder.add_from_file(os.path.join(GTKDYNAMO_GUI,"ambertools_w22.glade")) 







class new_file_search_window():
	""" Class doc """
	def get_open_filename_amber(self, builder):
		""" Function doc """
		data_path       = HOME         = os.environ.get('HOME')
		_01_window_main = builder.get_object("22_window_tleap")
		filename  = None
		
		chooser   = gtk.FileChooserDialog("Open File...", _01_window_main,
										gtk.FILE_CHOOSER_ACTION_OPEN,
										(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, 
										 gtk.STOCK_OPEN, gtk.RESPONSE_OK))

		chooser.add_filter(filter)
		filter = gtk.FileFilter()
		filter.set_name("All files")
		filter.add_pattern("*")
		
		chooser.add_filter(filter)	          # termina  - filtro de arquivos.
		chooser.set_current_folder(data_path)
		response = chooser.run()
		if response == gtk.RESPONSE_OK: filename = chooser.get_filename()
		chooser.destroy()

		return filename	

	
	
	
	
class tleap_window():

	def on_22_window_tleap_button5_clicked (self, button):
		""" Function doc """
		print button

	def on_22_window_tleap_button2_clicked (self, button):
		""" Function doc """
		print button

	def on_22_window_tleap_button1_clicked(self, button):
		print button
		new_file  =  new_file_search_window()
		filein    =  new_file.get_open_filename_amber(self.builder)
		
		model = self.builder.get_object("liststore1") #@+
		model.clear()
		data = [filein,"bolota mesmo"]
		model.append(data)


	def SETUP_COMBOBOXES(self):
		cbox = self.builder.get_object('22_window_tleap_combobox5')
		store = gtk.ListStore(gobject.TYPE_STRING)
		#print store
		cbox.set_model(store )
		cbox.append_text("ff99SB")
		cbox.append_text("ff99SBildn")
		cbox.append_text("ff99SBnmr")
		cbox.append_text("ff99bsc0")
		cbox.append_text("ff99SB")
		cbox.append_text("ffAM1")
		cbox.append_text("ffPM3")
		cbox.append_text("ff02polEP")
		cbox.append_text("ff02pol")
		cbox.append_text("ff03")
		cell = gtk.CellRendererText()
		cbox.pack_start(cell, True)
		cbox.add_attribute(cell, 'text', 0)  
		cbox.set_active(0)
		
		
		cbox = self.builder.get_object('22_window_tleap_combobox6')
		store = gtk.ListStore(gobject.TYPE_STRING)
		#print store
		cbox.set_model(store )
		cbox.append_text("GLYCAM_04EP")
		cbox.append_text("GLYCAM_06")
		cell = gtk.CellRendererText()
		cbox.pack_start(cell, True)
		cbox.add_attribute(cell, 'text', 0)  
		cbox.set_active(1)

		cbox = self.builder.get_object('22_window_tleap_combobox3')
		store = gtk.ListStore(gobject.TYPE_STRING)
		#print store
		cbox.set_model(store )
		cbox.append_text("TIP3P")
		cbox.append_text("TIP4P")
		cbox.append_text("TIP5P")
		cbox.append_text("TIP6P")
		cbox.append_text("TIP7P")
		cell = gtk.CellRendererText()
		cbox.pack_start(cell, True)
		cbox.add_attribute(cell, 'text', 0)  
		cbox.set_active(0)

		cbox = self.builder.get_object('22_window_tleap_combobox1')
		store = gtk.ListStore(gobject.TYPE_STRING)
		#print store
		cbox.set_model(store )
		cbox.append_text("Na+")
		cbox.append_text("K+")
		cbox.append_text("Mg2+")
		cbox.append_text("Cs+")
		cell = gtk.CellRendererText()
		cbox.pack_start(cell, True)
		cbox.add_attribute(cell, 'text', 0)  
		cbox.set_active(0)
		
		cbox = self.builder.get_object('22_window_tleap_combobox2')
		store = gtk.ListStore(gobject.TYPE_STRING)
		#print store
		cbox.set_model(store )
		cbox.append_text("Cl-")
		cbox.append_text("Br-")
		#cbox.append_text("Mg2+")
		#cbox.append_text("Cs+")
		cell = gtk.CellRendererText()
		cbox.pack_start(cell, True)
		cbox.add_attribute(cell, 'text', 0)  
		cbox.set_active(0)		
	
	def __init__ (self):
		""" Class initialiser """
		self.builder = builder
		
		file_list = [["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"],
					 ["file1","tipo de bolota"]]
		
		model = self.builder.get_object("liststore1") #@+
		model.clear()
		
		n = 0
		for i in file_list:
			data = ["gordao","bolota mesmo"]
			model.append(data)
			n = n +1
		
		
		
		
		
		#self.window_main        = builder.get_object("22_window_tleap") 
		self.window_main        = builder.get_object("dialog1")
		
		self.window_main .show_all() 

		self.SETUP_COMBOBOXES()
		self.on_22_window_tleap_button2_clicked (True)
		gtk.main()
		
tleap_window =tleap_window()	
tleap_window.SETUP_COMBOBOXES()
